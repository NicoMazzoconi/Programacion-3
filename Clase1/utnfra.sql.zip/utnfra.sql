--
-- Base de datos: `utnfra`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `alumno`
--

CREATE TABLE `alumno` (
  `id` int(11) NOT NULL,
  `nombre` varchar(50) COLLATE utf8_spanish2_ci NOT NULL,
  `edad` int(99) NOT NULL,
  `dni` int(255) NOT NULL,
  `legajo` int(255) NOT NULL,
  `fecha` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `idLocalidad` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

--
-- Volcado de datos para la tabla `alumno`
--

INSERT INTO `alumno` (`id`, `nombre`, `edad`, `dni`, `legajo`, `fecha`, `idLocalidad`) VALUES
(1, 'Nicolas', 24, 38364000, 107308, '2019-04-08 20:06:13', 2),
(2, 'GGT', 25, 35452123, 457852, '2019-04-08 20:06:13', 2),
(3, 'Pablo', 26, 25456789, 897541, '2019-04-08 20:06:13', 3),
(4, 'Fabian', 29, 21258963, 202010, '2019-04-08 20:06:13', 3),
(5, 'Pedro', 17, 42364000, 524698, '2019-04-08 20:06:13', 1),
(7, 'Juan', 21, 1245787, 120145, '2019-04-08 21:10:26', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `localidad`
--

CREATE TABLE `localidad` (
  `id` int(11) NOT NULL,
  `codigoPostal` int(255) NOT NULL,
  `nombre` varchar(50) COLLATE utf8_spanish2_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

--
-- Volcado de datos para la tabla `localidad`
--

INSERT INTO `localidad` (`id`, `codigoPostal`, `nombre`) VALUES
(1, 1900, 'La Plata'),
(2, 1081, 'Congreso'),
(3, 1031, 'Once');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `materia`
--

CREATE TABLE `materia` (
  `id` int(11) NOT NULL,
  `descripcion` varchar(255) COLLATE utf8_spanish2_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

--
-- Volcado de datos para la tabla `materia`
--

INSERT INTO `materia` (`id`, `descripcion`) VALUES
(1, 'Programacion'),
(2, 'Laboratorio'),
(3, 'Matematica');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `materiaalumno`
--

CREATE TABLE `materiaalumno` (
  `idMateria` int(11) NOT NULL,
  `idAlumno` int(11) NOT NULL,
  `cuatrimestre` int(50) NOT NULL,
  `nota` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

--
-- Volcado de datos para la tabla `materiaalumno`
--

INSERT INTO `materiaalumno` (`idMateria`, `idAlumno`, `cuatrimestre`, `nota`) VALUES
(1, 1, 1, 10),
(1, 4, 2, 4),
(2, 2, 1, 8),
(2, 5, 2, 2),
(3, 3, 1, 6),
(3, 7, 2, 1);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `alumno`
--
ALTER TABLE `alumno`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `localidad`
--
ALTER TABLE `localidad`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `materia`
--
ALTER TABLE `materia`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `materiaalumno`
--
ALTER TABLE `materiaalumno`
  ADD PRIMARY KEY (`idMateria`,`idAlumno`,`cuatrimestre`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `alumno`
--
ALTER TABLE `alumno`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT de la tabla `localidad`
--
ALTER TABLE `localidad`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT de la tabla `materia`
--
ALTER TABLE `materia`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
