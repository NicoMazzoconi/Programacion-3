<?php  
namespace App\Models;
 
class encuesta extends \Illuminate\Database\Eloquent\Model{  
    public $timestamps = false;
}
?>