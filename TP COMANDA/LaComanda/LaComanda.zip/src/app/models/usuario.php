<?php  
namespace App\Models;
 
class usuario extends \Illuminate\Database\Eloquent\Model{  
    public $timestamps = false;
}
?>
