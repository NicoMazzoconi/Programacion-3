<?php  
namespace App\Models;
 
class pedido extends \Illuminate\Database\Eloquent\Model{  
    public $timestamps = false;
}
?>
