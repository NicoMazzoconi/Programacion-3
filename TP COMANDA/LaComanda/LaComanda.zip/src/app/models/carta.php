<?php  
namespace App\Models;
 
class carta extends \Illuminate\Database\Eloquent\Model{  
    public $timestamps = false;
}
?>