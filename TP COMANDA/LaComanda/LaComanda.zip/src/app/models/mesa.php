<?php  
namespace App\Models;
 
class mesa extends \Illuminate\Database\Eloquent\Model{  
    public $timestamps = false;
}
?>